// Páginas do painel administrativo
import { esc, reais, dt } from './paginas.js';
import { formatarDoc } from './pdf.js';

export const menu = (ativo) => `<nav style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px" aria-label="Administração">
  ${[['/admin', 'Resumo'], ['/admin/financeiro', 'Financeiro'], ['/admin/produtos', 'Consultas e preços'], ['/admin/clientes', 'Clientes'], ['/admin/rede', 'Rede de clientes'], ['/admin/consultas', 'Consultas feitas'], ['/admin/recargas', 'Recargas'], ['/admin/operacao', 'Operação'], ['/admin/limpa-nome', 'Limpa Nome (serviço)'], ['/admin/rating', 'Rating Bancário'], ['/admin/parceiros', 'Parceiros'], ['/admin/monitoramento', 'Monitoramento'], ['/admin/ebook', 'Ebook'], ['/admin/raio-x/vendas', 'Vendas Raio-X'], ['/admin/raio-x', 'Raio-X (config.)'], ['/admin/saques', 'Saques de comissão'], ['/admin/campanhas', 'Campanhas'], ['/admin/anuncios', 'Anúncios'], ['/admin/backups', 'Backups'], ['/admin/registro', 'Registro'], ['/admin/config', 'Configurações']]
    .map(([h, t]) => `<a class="btn ${h === ativo ? '' : 'sec'}" style="min-height:40px;padding:8px 18px" href="${h}">${t}</a>`).join('')}
</nav>`;
const num = (rot, val, sub = '') => `<div class="cartao"><div class="muted">${rot}</div><div style="font-family:Montserrat,sans-serif;font-size:1.8rem;font-weight:800">${val}</div>${sub ? `<div class="muted" style="font-size:.85rem">${sub}</div>` : ''}</div>`;
const aviso = (ok, erro) => (ok ? `<div class="aviso ok">${esc(ok)}</div>` : '') + (erro ? `<div class="aviso erro">${esc(erro)}</div>` : '');

export function adminResumo({ m, ok }) {
  const baixo = m.saldoApiFull !== null && m.saldoApiFull < m.alertaApiFull;
  return `<h1 style="font-size:1.7rem">Administração</h1>${menu('/admin')}${aviso(ok)}
${m.saldoApiFull === null ? '<div class="aviso erro">Não foi possível ler o saldo da APIFull agora. Confira o APIFULL_TOKEN no Render.</div>' : ''}
${baixo ? `<div class="aviso erro" role="alert"><strong>Saldo da APIFull baixo: ${reais(m.saldoApiFull)}.</strong> Se acabar, as consultas dos clientes falham. <a href="https://app.apifull.com.br" target="_blank" rel="noopener">Recarregar na APIFull</a></div>` : ''}
<div class="grade" style="margin-bottom:18px">
  <div class="cartao" style="${baixo ? 'border-color:var(--erro)' : ''}"><div class="muted">Saldo na APIFull</div>
    <div style="font-family:Montserrat,sans-serif;font-size:1.8rem;font-weight:800;color:${baixo ? 'var(--erro)' : 'inherit'}">${m.saldoApiFull === null ? '—' : reais(m.saldoApiFull)}</div>
    <div class="muted" style="font-size:.85rem">alerta abaixo de ${reais(m.alertaApiFull)} · <a href="https://app.apifull.com.br" target="_blank" rel="noopener">recarregar</a></div></div>
  ${num('Consultas internas (admin e contas internas)', m.internas, `custo ${reais(m.custoInternas)}, pago direto na APIFull`)}
</div>
<div class="grade" style="margin-bottom:18px">
  ${num('Clientes', m.clientes, `${m.clientesMes} nos últimos 30 dias`)}
  ${num('Recargas pagas', reais(m.recargas), `${m.qtdRecargas} recargas · ${reais(m.bonus)} em bônus`)}
  ${num('Saldo em carteiras', reais(m.saldos), 'créditos ainda não usados')}
</div>
<div class="grade">
  ${num('Consultas concluídas', m.consultas, `${m.falhas} falharam e foram estornadas`)}
  ${num('Faturamento com consultas', reais(m.faturamento), 'sem as comissões de indicação')}
  ${num('Custo APIFull', reais(m.custo), `Margem: ${reais(m.faturamento - m.custo)}`)}
</div>
<div class="grade" style="margin-top:18px">
  ${num('Comissões de indicação', reais(m.comissoes), 'pagas pelos indicados, acima do seu preço')}
  ${num('Saques a pagar', reais(m.saquesPendentes), `${m.qtdSaquesPendentes} pedido(s) aguardando · <a href="/admin/saques">ver</a>`)}
</div>`;
}

export function adminProdutos({ produtos, markup, ok }) {
  return `<h1 style="font-size:1.7rem">Consultas e preços</h1>${menu('/admin/produtos')}${aviso(ok)}
<p class="muted">Preço de venda = custo APIFull + ${markup}% (ajuste a porcentagem em Configurações). Só aparecem para os clientes as consultas <strong>ativas</strong> e com endpoint preenchido.</p>
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>Consulta</th><th>Categoria</th><th>Endpoint</th><th>Custo</th><th>Preço</th><th>Lucro por consulta</th><th>Status</th><th></th></tr>
  ${produtos.map((p) => `<tr><td><strong>${esc(p.nome)}</strong>${p.custo_centavos ? '' : ' <span class="tag" style="color:var(--erro)">sem custo</span>'}${p.sensivel ? ' <span class="tag">sensível</span>' : ''}</td><td>${esc(p.categoria)}</td><td><code>${esc(p.endpoint || '—')}</code></td>
    <td>${reais(p.custo_centavos)}</td><td><strong>${reais(p.preco_centavos)}</strong>${p.markup_percentual !== null && p.markup_percentual !== undefined ? `<br><small class="tag">margem ${p.markup_percentual}%</small>` : ''}</td>
    <td>${p.custo_centavos ? `<strong style="color:var(--ok)">${reais(p.preco_centavos - p.custo_centavos)}</strong><br><small class="muted">${Math.round(((p.preco_centavos - p.custo_centavos) / p.custo_centavos) * 100)}% sobre o custo</small>` : '—'}</td>
    <td>${p.ativo && p.endpoint ? '<span style="color:var(--ok);font-weight:700">Ativa</span>' : '<span class="muted">Inativa</span>'}</td>
    <td><a href="/admin/produtos/editar?id=${p.id}">Editar</a></td></tr>`).join('')}
</table></div>
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px"><a class="btn" href="/admin/produtos/editar">+ Nova consulta</a><a class="btn sec" href="/admin/produtos/importar">Importar em lote</a></div></div>`;
}

export function adminProdutoForm({ p = {}, markup, erro }) {
  const campo = (id, rot, val, extra = '') => `<div class="campo"><label for="${id}">${rot}</label><input id="${id}" name="${id}" type="text" value="${esc(val ?? '')}" ${extra}></div>`;
  return `<h1 style="font-size:1.7rem">${p.id ? 'Editar consulta' : 'Nova consulta'}</h1>${menu('/admin/produtos')}${aviso('', erro)}
<form class="cartao" method="post" action="/admin/produtos/salvar" style="max-width:640px">
  ${p.id ? `<input type="hidden" name="id" value="${p.id}">` : ''}
  ${campo('nome', 'Nome (como aparece para o cliente)', p.nome, 'required')}
  ${campo('categoria', 'Categoria', p.categoria || 'Dívidas e Crédito', 'required')}
  ${campo('descricao', 'Descrição curta', p.descricao)}
  <div class="campo"><label for="documento">O cliente informa</label>
    <select id="documento" name="documento" style="font:inherit;padding:13px 15px;border:1.5px solid #D6CCE0;border-radius:12px;min-height:48px;background:#fff">
      ${[['cpf_cnpj', 'CPF ou CNPJ'], ['cpf', 'Somente CPF'], ['cnpj', 'Somente CNPJ'], ['placa', 'Placa de veículo'], ['cep', 'CEP']].map(([v, t]) => `<option value="${v}" ${p.documento === v ? 'selected' : ''}>${t}</option>`).join('')}
    </select></div>
  ${campo('endpoint', 'Endpoint na APIFull (ex.: e-boavista)', p.endpoint)}
  ${campo('link', 'Link na APIFull (normalmente igual ao endpoint)', p.link)}
  ${campo('campo', 'Nome do campo enviado (padrão: document; para placa geralmente: placa)', p.campo || 'document')}
  ${campo('custo', 'Custo na APIFull (R$)', p.custo_centavos != null ? (p.custo_centavos / 100).toFixed(2).replace('.', ',') : '', 'inputmode="decimal" required')}
  ${campo('markup_proprio', `Margem própria desta consulta (%) · deixe vazio para usar a geral (${markup}%)`, p.markup_percentual ?? '', 'inputmode="decimal"')}
  <p class="muted" style="margin-top:-8px">Preço de venda = custo + margem. Use uma margem própria para deixar consultas específicas mais competitivas (ex.: veículos com 80%).</p>
  ${campo('ordem', 'Ordem no catálogo (menor aparece primeiro)', p.ordem ?? 100, 'inputmode="numeric"')}
  <label class="check"><input type="checkbox" name="ativo" value="1" ${p.ativo ? 'checked' : ''}><span>Ativa (visível para os clientes)</span></label>
  <label class="check"><input type="checkbox" name="sensivel" value="1" ${p.sensivel ? 'checked' : ''}><span>Consulta sensível (só contas CNPJ ou clientes liberados por você)</span></label>
  <div class="campo"><label for="destaque_limpa_nome">Área Limpa Nome</label>
    <select id="destaque_limpa_nome" name="destaque_limpa_nome" style="font:inherit;padding:13px 15px;border:1.5px solid #D6CCE0;border-radius:12px;min-height:48px;background:#fff">
      ${[['', 'Não aparece'], ['economica', 'Mais em conta (triagem)'], ['completa', 'Mais completa (diagnóstico)']].map(([v, t]) => `<option value="${v}" ${(p.destaque_limpa_nome || '') === v ? 'selected' : ''}>${t}</option>`).join('')}
    </select></div>
  <button class="btn" type="submit">Salvar</button> <a class="btn sec" href="/admin/produtos">Cancelar</a>
</form>`;
}

export function adminConfig({ maximo = 100000, minimo, faixas, markup, dias = 10, comissaoMax = 100, saqueMin = 5000, taxaSaque = 5, alerta = 5000, primeira = { pct: 0, min: 0, ate: '' }, ok, erro }) {
  return `<h1 style="font-size:1.7rem">Configurações</h1>${menu('/admin/config')}${aviso(ok, erro)}
<form class="cartao" method="post" action="/admin/config" style="max-width:640px">
  <div class="campo"><label for="markup">Margem sobre o custo APIFull (%)</label><input id="markup" name="markup" type="text" inputmode="numeric" value="${markup}">
    <small class="muted">150 = preço de venda é o custo + 150% (custo x 2,5). Ao salvar, todos os preços são recalculados.</small></div>
  <div class="campo"><label for="minimo">Recarga mínima (R$)</label><input id="minimo" name="minimo" type="text" inputmode="decimal" value="${(minimo / 100).toFixed(2).replace('.', ',')}"></div>
  <div class="campo"><label for="maximo">Recarga máxima por Pix (R$)</label><input id="maximo" name="maximo" type="text" inputmode="decimal" value="${(maximo / 100).toFixed(2).replace('.', ',')}"><small class="muted">Acima de R$ 300 o cliente confirma o valor antes de gerar o Pix.</small></div>
  <div class="campo"><label for="faixas">Bônus de recarga</label>
    <input id="faixas" name="faixas" type="text" value="${esc(faixas.map((f) => `${f.a_partir_de / 100}=${f.percentual}`).join('; '))}">
    <small class="muted">Formato: valor=percentual, separados por ponto e vírgula. Ex.: <code>100=5; 300=10</code> (a partir de R$ 100 ganha 5%, a partir de R$ 300 ganha 10%). Deixe vazio para não dar bônus.</small></div>
  <fieldset style="border:1px solid var(--borda);border-radius:14px;padding:14px 16px;margin:0 0 16px"><legend style="font-weight:700;padding:0 6px">Oferta de primeira recarga</legend>
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <div class="campo" style="flex:1 1 140px;margin:0"><label for="primeira_pct">Bônus (%)</label><input id="primeira_pct" name="primeira_pct" type="text" inputmode="numeric" value="${primeira.pct}"></div>
      <div class="campo" style="flex:1 1 160px;margin:0"><label for="primeira_min">A partir de (R$)</label><input id="primeira_min" name="primeira_min" type="text" inputmode="decimal" value="${(primeira.min / 100).toFixed(2).replace('.', ',')}"></div>
      <div class="campo" style="flex:1 1 180px;margin:0"><label for="primeira_ate">Válida até</label><input id="primeira_ate" name="primeira_ate" type="date" value="${primeira.ate || ''}" style="font:inherit;padding:11px 13px;border:1.5px solid #D6CCE0;border-radius:12px"></div>
    </div>
    <small class="muted">Vale só na primeira recarga paga de cada cliente e aparece nas páginas de campanha. Coloque 0% para desligar.</small></fieldset>
  <div class="campo"><label for="dias">Dias de histórico disponível para o cliente</label><input id="dias" name="dias" type="text" inputmode="numeric" value="${dias}">
    <small class="muted">Depois desse prazo, o resultado e o PDF de cada consulta são apagados automaticamente (LGPD). O registro da consulta continua no Admin.</small></div>
  <div class="campo"><label for="comissao_maxima">Comissão máxima de indicação (%)</label><input id="comissao_maxima" name="comissao_maxima" type="text" inputmode="numeric" value="${comissaoMax}">
    <small class="muted">Limite que cada usuário pode somar ao preço das consultas dos indicados.</small></div>
  <div class="campo"><label for="alerta_apifull">Avisar quando o saldo da APIFull ficar abaixo de (R$)</label><input id="alerta_apifull" name="alerta_apifull" type="text" inputmode="decimal" value="${(alerta / 100).toFixed(2).replace('.', ',')}"></div>
  <div class="campo"><label for="saque_minimo">Saque mínimo de comissões (R$)</label><input id="saque_minimo" name="saque_minimo" type="text" inputmode="decimal" value="${(saqueMin / 100).toFixed(2).replace('.', ',')}"></div>
  <div class="campo"><label for="saque_taxa">Taxa sobre saque de comissões (%)</label><input id="saque_taxa" name="saque_taxa" type="text" inputmode="decimal" value="${taxaSaque}">
    <small class="muted">Descontada do valor sacado: num saque de R$ 100 com 5%, o Pix enviado é de R$ 95. Recargas (depósitos) nunca podem ser sacadas, só comissões.</small></div>
  <button class="btn" type="submit">Salvar configurações</button>
</form>`;
}

export function adminClientes({ clientes, busca = '', ok, erro }) {
  return `<h1 style="font-size:1.7rem">Clientes</h1>${menu('/admin/clientes')}${aviso(ok, erro)}
<form method="get" class="cartao" style="padding:16px;display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">
  <input type="text" name="busca" value="${esc(busca)}" placeholder="Nome, e-mail ou documento" aria-label="Buscar cliente" style="flex:1 1 220px"><button class="btn">Buscar</button></form>
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>Cliente</th><th>Documento</th><th>WhatsApp</th><th>Saldo</th><th>Desde</th><th>Consultas sensíveis</th><th>Ajustar saldo</th></tr>
  ${clientes.map((c) => `<tr><td><strong>${esc(c.nome)}</strong><br><span class="muted">${esc(c.email)}</span>${c.ativo ? '' : ' <span style="color:var(--erro);font-weight:700">(bloqueado)</span>'}
      ${c.admin ? '' : `<form method="post" action="/admin/clientes/ativo" style="margin:6px 0 0"><input type="hidden" name="id" value="${c.id}"><input type="hidden" name="ativo" value="${c.ativo ? 0 : 1}"><button class="btn sec" style="min-height:32px;padding:4px 10px;font-size:.8rem${c.ativo ? ';color:var(--erro)' : ''}" ${c.ativo ? `data-confirmar="Bloquear ${esc(c.nome)}? A pessoa é desconectada e não consegue mais entrar. O saldo fica preservado."` : ''}>${c.ativo ? 'Bloquear' : 'Reativar'}</button></form>`}</td>
    <td>${esc(formatarDoc(c.documento))}</td><td>${esc(c.telefone)}</td><td><strong>${reais(c.saldo)}</strong>${c.admin ? '<br><span class="tag">admin</span>' : c.interno ? '<br><span class="tag">interna · saldo APIFull</span>' : ''}
      ${c.admin ? '' : `<form method="post" action="/admin/clientes/interno" style="margin:6px 0 0"><input type="hidden" name="id" value="${c.id}"><input type="hidden" name="interno" value="${c.interno ? 0 : 1}"><button class="btn sec" style="min-height:30px;padding:4px 10px;font-size:.78rem">${c.interno ? 'Remover conta interna' : 'Tornar conta interna'}</button></form>`}</td><td>${dt(c.criado_em).slice(0, 10)}</td>
    <td>${c.documento.length === 14 ? '<span class="muted">liberadas (CNPJ)</span>' : `<form method="post" action="/admin/clientes/sensivel" style="margin:0"><input type="hidden" name="id" value="${c.id}"><input type="hidden" name="liberar" value="${c.liberado_sensivel ? 0 : 1}">
      <button class="btn ${c.liberado_sensivel ? 'sec' : ''}" style="min-height:36px;padding:6px 12px;font-size:.85rem">${c.liberado_sensivel ? 'Liberadas · bloquear' : 'Liberar'}</button></form>`}</td>
    <td><form method="post" action="/admin/clientes/ajuste" style="display:flex;gap:6px;flex-wrap:wrap;margin:0">
      <input type="hidden" name="id" value="${c.id}">
      <input type="text" name="valor" placeholder="+10 ou -10" aria-label="Valor do ajuste" style="width:100px;min-height:40px;padding:8px">
      <input type="text" name="motivo" placeholder="Motivo" aria-label="Motivo" style="width:140px;min-height:40px;padding:8px">
      <button class="btn sec" style="min-height:40px;padding:8px 14px">Aplicar</button></form></td></tr>`).join('')}
</table></div></div>`;
}

export function adminConsultas({ consultas, ok, erro }) {
  return `<h1 style="font-size:1.7rem">Consultas feitas</h1>${menu('/admin/consultas')}${aviso(ok, erro)}
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>#</th><th>Data</th><th>Cliente</th><th>Consulta</th><th>Documento</th><th>Finalidade</th><th>Cliente pagou</th><th>Custo APIFull</th><th>Comissão</th><th>Seu lucro</th><th>Status</th></tr>
  ${consultas.map((c) => `<tr><td>${c.id}</td><td>${dt(c.criado_em)}</td><td>${esc(c.cliente)}</td><td>${esc(c.produto)}</td><td>${esc(formatarDoc(c.parametro))}</td>
    <td style="max-width:200px">${esc(c.finalidade || '-')}</td>
    <td>${c.interno ? '<span class="muted">interna</span>' : reais(c.preco_centavos)}</td><td>${reais(c.custo_centavos || 0)}</td>
    <td>${c.comissao_centavos ? reais(c.comissao_centavos) : '—'}</td>
    <td>${c.status === 'concluida' && !c.interno ? `<strong style="color:var(--ok)">${reais(c.preco_centavos - (c.comissao_centavos || 0) - (c.custo_centavos || 0))}</strong>` : '—'}</td>
    <td>${c.status === 'concluida' ? (c.estornada ? '<span class="muted">Concluída · estornada</span>' : `Concluída${c.interno ? '' : `<form method="post" action="/admin/consultas/estornar" style="margin:6px 0 0;display:flex;gap:4px;flex-wrap:wrap"><input type="hidden" name="id" value="${c.id}"><input type="text" name="motivo" placeholder="Motivo" aria-label="Motivo do estorno" style="width:110px;min-height:32px;padding:4px 8px"><button class="btn sec" style="min-height:32px;padding:4px 10px;font-size:.8rem" data-confirmar="Devolver ${reais(c.preco_centavos)} ao cliente?">Estornar</button></form>`}`) : c.status === 'falhou' ? `<span style="color:var(--erro)" title="${esc(c.erro || '')}">Falhou · estornada</span>` : 'Processando'}</td></tr>`).join('')}
</table></div></div>`;
}

export function adminRecargas({ recargas, ok, erro }) {
  return `<h1 style="font-size:1.7rem">Recargas</h1>${menu('/admin/recargas')}${aviso(ok, erro)}
<p class="muted">Cliente diz que pagou e o saldo não entrou? Use <strong>Conferir no Asaas</strong>: se o Pix foi pago, o crédito entra na hora (nunca em dobro).</p>
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>#</th><th>Data</th><th>Cliente</th><th>Valor</th><th>Bônus</th><th>Status</th><th>Pago em</th></tr>
  ${recargas.map((r) => `<tr><td>${r.id}</td><td>${dt(r.criado_em)}</td><td>${esc(r.cliente)}</td><td>${reais(r.valor_centavos)}</td><td>${reais(r.bonus_centavos)}</td>
    <td>${r.status === 'paga' ? '<span style="color:var(--ok);font-weight:700">Paga</span>' : r.status === 'expirada' ? '<span class="muted">Expirada (não paga)</span>' : `Pendente${r.asaas_id ? `<form method="post" action="/admin/recargas/verificar" style="margin:6px 0 0"><input type="hidden" name="id" value="${r.id}"><button class="btn sec" style="min-height:32px;padding:4px 10px;font-size:.8rem">Conferir no Asaas</button></form>` : ''}`}</td><td>${dt(r.pago_em)}</td></tr>`).join('')}
</table></div></div>`;
}

export function adminImportar({ texto = '', resultado, erro }) {
  return `<h1 style="font-size:1.7rem">Importar consultas em lote</h1>${menu('/admin/produtos')}${aviso('', erro)}
${resultado ? `<div class="aviso ok">${esc(resultado)}</div>` : ''}
<div class="cartao" style="margin-bottom:18px">
  <h3>Como preencher</h3>
  <p class="muted">Uma consulta por linha, com os campos separados por ponto e vírgula (;). Nome e endpoint são obrigatórios:</p>
  <p><code>Nome; Endpoint; Custo; Categoria; Documento; Descrição; Campo</code></p>
  <ul class="muted">
    <li><strong>Custo:</strong> valor na APIFull, ex.: <code>5,83</code>. O preço de venda é calculado sozinho. <strong>Sem custo, a consulta entra inativa</strong> até você informar o custo.</li>
    <li><strong>Campo</strong> (opcional): nome do campo enviado à APIFull. Padrão: <code>document</code> (ou <code>placa</code> para veículos).</li>
    <li><strong>Categoria</strong> (opcional): ex.: Dívidas e Crédito, Veículos, Empresas, Dados. Padrão: Dívidas e Crédito.</li>
    <li><strong>Documento</strong> (opcional): <code>cpf_cnpj</code> (padrão), <code>cpf</code>, <code>cnpj</code>, <code>placa</code> ou <code>cep</code>.</li>
    <li>Se o endpoint já estiver cadastrado, a consulta é <strong>atualizada</strong>. Se não, é criada (ativa quando tem custo).</li>
  </ul>
  <p class="muted" style="margin:0">Exemplo:<br><code>Serasa Premium; serasa-premium; 15,72; Dívidas e Crédito; cpf_cnpj; Score e negativações Serasa</code><br><code>Consulta Veicular Completa; veiculo-completo; 12,50; Veículos; placa</code></p>
</div>
<form class="cartao" method="post" action="/admin/produtos/importar">
  <label for="texto">Cole a lista aqui</label>
  <textarea id="texto" name="texto" rows="14" style="width:100%;font:inherit;font-family:monospace;font-size:.9rem;padding:12px;border:1.5px solid #D6CCE0;border-radius:12px;margin:8px 0 14px">${esc(texto)}</textarea>
  <button class="btn" type="submit">Importar</button>
</form>`;
}

export function adminSaques({ saques, ok, erro }) {
  const st = { pendente: '<strong>Pendente</strong>', pago: '<span style="color:var(--ok);font-weight:700">Pago</span>', recusado: '<span style="color:var(--erro)">Recusado</span>' };
  return `<h1 style="font-size:1.7rem">Saques de comissão</h1>${menu('/admin/saques')}${aviso(ok, erro)}
<p class="muted"><strong>Pagar via Asaas</strong> envia o Pix automaticamente da sua conta Asaas para a chave do usuário. Se preferir pagar por outro banco, faça o Pix do valor da coluna <strong>Pix a enviar</strong> (já descontada a taxa) e clique em <strong>Já paguei</strong>. Se recusar, o valor volta para o saldo de comissões do usuário. Antes de pagar, confira se a chave Pix é do mesmo titular (CPF/CNPJ) da conta.</p>
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>#</th><th>Data</th><th>Usuário</th><th>Valor do saque</th><th>Taxa</th><th>Pix a enviar</th><th>Chave Pix</th><th>Status</th><th>Ação</th></tr>
  ${saques.map((x) => `<tr><td>${x.id}</td><td>${dt(x.criado_em)}</td><td>${esc(x.nome)}<br><span class="muted">${esc(formatarDoc(x.documento))}</span></td>
    <td>${reais(x.valor_centavos)}</td><td>${reais(x.taxa_centavos || 0)}</td><td><strong>${reais(x.valor_centavos - (x.taxa_centavos || 0))}</strong></td><td><code>${esc(x.chave_pix)}</code></td><td>${st[x.status]}${x.observacao ? `<br><small class="muted">${esc(x.observacao)}</small>` : ''}</td>
    <td>${x.status === 'pendente' ? `<form method="post" action="/admin/saques/resolver" style="display:flex;gap:6px;flex-wrap:wrap;margin:0">
      <input type="hidden" name="id" value="${x.id}"><input type="text" name="obs" placeholder="Observação" aria-label="Observação" style="width:130px;min-height:40px;padding:8px">
      <button class="btn" name="acao" value="asaas" style="min-height:40px;padding:8px 14px" data-confirmar="Enviar ${reais(x.valor_centavos - (x.taxa_centavos || 0))} por Pix pelo Asaas para a chave ${esc(x.chave_pix)}?">Pagar via Asaas</button>
      <button class="btn sec" name="acao" value="pagar" style="min-height:40px;padding:8px 14px">Já paguei</button>
      <button class="btn sec" name="acao" value="recusar" style="min-height:40px;padding:8px 14px">Recusar</button></form>` : '-'}</td></tr>`).join('') || '<tr><td colspan="9" class="vazio">Nenhum saque solicitado.</td></tr>'}
</table></div></div>`;
}

export function adminBackups({ backups, ok, persistente }) {
  const kb = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
  return `<h1 style="font-size:1.7rem">Backups</h1>${menu('/admin/backups')}${aviso(ok)}
<div class="cartao" style="margin-bottom:18px">
  <p style="margin-top:0">O sistema faz uma cópia completa do banco de dados (clientes, saldos, recargas, consultas, comissões e configurações):</p>
  <ul class="muted"><li><strong>a cada atualização do site</strong>, antes de qualquer ajuste;</li><li><strong>uma vez por dia</strong>, automaticamente;</li><li>e quando você clicar em "Fazer backup agora".</li></ul>
  <p class="muted">Ficam guardadas as 30 cópias mais recentes. ${persistente ? '' : '<strong style="color:var(--erro)">Atenção: sem o disco permanente, os backups também são apagados nas atualizações.</strong>'}
  Baixe uma cópia de vez em quando (por exemplo, toda semana) e guarde num lugar seguro: o arquivo contém dados pessoais dos clientes.</p>
  <form method="post" action="/admin/backups/criar"><button class="btn" type="submit">Fazer backup agora</button></form>
</div>
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>Data</th><th>Arquivo</th><th>Tamanho</th><th></th></tr>
  ${backups.map((b) => `<tr><td>${esc(new Date(b.data).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }))}</td><td><code>${esc(b.nome)}</code></td><td>${kb(b.tamanho)}</td>
    <td><a href="/admin/backups/baixar?arquivo=${encodeURIComponent(b.nome)}">Baixar</a></td></tr>`).join('') || '<tr><td colspan="4" class="vazio">Nenhum backup ainda.</td></tr>'}
</table></div></div>`;
}

export function adminRede({ clientes, busca = '' }) {
  const porId = new Map(clientes.map((c) => [c.id, { ...c, filhos: [] }]));
  const raizes = [];
  for (const c of porId.values()) {
    const pai = c.indicado_por && porId.get(c.indicado_por);
    if (pai && pai.id !== c.id) pai.filhos.push(c); else raizes.push(c);
  }
  // Totais da rede (o próprio cliente + todos abaixo dele)
  const totais = (n) => n.filhos.reduce((t, f) => { const x = totais(f); return { pessoas: t.pessoas + x.pessoas, lucro: t.lucro + x.lucro, consultas: t.consultas + x.consultas }; },
    { pessoas: 1, lucro: n.lucro, consultas: n.consultas });
  const t = busca.toLowerCase();
  const casa = (n) => !t || `${n.nome} ${n.email} ${n.documento}`.toLowerCase().includes(t) || n.filhos.some(casa);
  const linha = (n, nivel) => {
    const tot = totais(n);
    const info = `<div style="display:flex;flex-wrap:wrap;gap:6px 18px;align-items:baseline">
        <strong>${esc(n.nome)}</strong>${n.admin ? ' <span class="tag">admin</span>' : ''}${n.ativo ? '' : ' <span class="tag" style="color:var(--erro)">desativado</span>'}
        <span class="muted">${esc(n.email)} · ${esc(formatarDoc(n.documento))} · ${esc(n.telefone)}</span></div>
      <div class="muted" style="font-size:.88rem;display:flex;flex-wrap:wrap;gap:4px 16px;margin-top:4px">
        <span>Saldo: <strong>${reais(n.saldo)}</strong></span><span>Recarregou: ${reais(n.recarregado)}</span>
        <span>Consultas: ${n.consultas}</span><span>Seu lucro com ele: <strong style="color:var(--ok)">${reais(n.lucro)}</strong></span>
        ${n.filhos.length ? `<span>Indicados diretos: <strong>${n.filhos.length}</strong> (comissão ${n.comissao_percentual}%)</span>
        <span>Comissões ganhas: ${reais(n.comissoes_ganhas)} · a sacar: ${reais(n.comissoes_saldo)}</span>
        <span>Rede total: ${tot.pessoas - 1} pessoa(s), ${tot.consultas} consultas, lucro ${reais(tot.lucro)}</span>` : ''}
        <span>Desde ${dt(n.criado_em).slice(0, 10)}</span></div>`;
    const filhos = n.filhos.filter(casa);
    return filhos.length
      ? `<details ${nivel === 0 && !t ? '' : 'open'} style="border-left:3px solid ${nivel ? 'var(--borda)' : 'var(--roxo)'};padding:10px 0 10px 14px;margin:8px 0 8px ${nivel ? 18 : 0}px">
          <summary style="cursor:pointer;list-style:none">${info}</summary>${filhos.map((f) => linha(f, nivel + 1)).join('')}</details>`
      : `<div style="border-left:3px solid var(--borda);padding:10px 0 10px 14px;margin:8px 0 8px ${nivel ? 18 : 0}px">${info}</div>`;
  };
  const visiveis = raizes.filter(casa);
  const totalIndicados = clientes.filter((c) => c.indicado_por).length;
  return `<h1 style="font-size:1.7rem">Rede de clientes</h1>${menu('/admin/rede')}
<div class="grade" style="margin-bottom:18px">
  ${num('Clientes', clientes.length)}${num('Chegaram por indicação', totalIndicados, `${clientes.length ? Math.round((totalIndicados / clientes.length) * 100) : 0}% da base`)}
  ${num('Indicadores ativos', new Set(clientes.filter((c) => c.indicado_por).map((c) => c.indicado_por)).size)}
</div>
<form method="get" class="cartao" style="padding:16px;display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">
  <input type="text" name="busca" value="${esc(busca)}" placeholder="Buscar por nome, e-mail ou documento" aria-label="Buscar na rede" style="flex:1 1 240px"><button class="btn">Buscar</button></form>
<div class="cartao"><p class="muted" style="margin-top:0">Clique num cliente com indicados para abrir a rede dele. A linha roxa marca quem chegou sem indicação.</p>
  ${visiveis.length ? visiveis.map((r) => linha(r, 0)).join('') : '<div class="vazio">Nenhum cliente encontrado.</div>'}
</div>`;
}

export function adminRegistro({ linhas }) {
  return `<h1 style="font-size:1.7rem">Registro de alterações</h1>${menu('/admin/registro')}
<p class="muted">Tudo o que é alterado no Admin fica registrado aqui, com data e responsável. Os 500 registros mais recentes são exibidos.</p>
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>Data</th><th>Quem</th><th>Ação</th><th>Detalhes</th></tr>
  ${linhas.map((l) => `<tr><td>${dt(l.criado_em)}</td><td>${esc(l.admin_email)}</td><td><strong>${esc(l.acao)}</strong></td><td>${esc(l.detalhe)}</td></tr>`).join('') || '<tr><td colspan="4" class="vazio">Nenhuma alteração registrada ainda.</td></tr>'}
</table></div></div>`;
}

// ---------- Painel financeiro ----------
function graficoDiario(dias, ini, fim) {
  // preenche dias sem movimento
  const mapa = new Map(dias.map((d) => [d.dia, d]));
  const lista = [];
  for (let t = new Date(ini + 'T12:00:00Z'); t <= new Date(fim + 'T12:00:00Z'); t.setUTCDate(t.getUTCDate() + 1)) {
    const k = t.toISOString().slice(0, 10);
    const d = mapa.get(k) || { receita: 0, custo: 0, n: 0 };
    lista.push({ dia: k, receita: d.receita, lucro: d.receita - d.custo, n: d.n });
  }
  const W = 900, H = 260, E = 54, B = 34, T = 14;
  const max = Math.max(100, ...lista.map((d) => d.receita));
  const larg = (W - E - 10) / lista.length;
  const y = (v) => T + (H - T - B) * (1 - v / max);
  const linhas = [0, 0.25, 0.5, 0.75, 1].map((f) => `<line x1="${E}" x2="${W - 10}" y1="${y(max * f)}" y2="${y(max * f)}" stroke="#EEE6F5"/>
    <text x="${E - 6}" y="${y(max * f) + 4}" text-anchor="end" font-size="11" fill="#5B5466">${(max * f / 100).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}</text>`).join('');
  const barras = lista.map((d, i) => `<rect x="${E + i * larg + larg * 0.15}" y="${y(d.receita)}" width="${Math.max(1, larg * 0.7)}" height="${H - B - y(d.receita)}" rx="3" fill="#E4CCF4"><title>${d.dia.split('-').reverse().join('/')}: faturamento ${(d.receita / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}, ${d.n} consulta(s)</title></rect>`).join('');
  const pontos = lista.map((d, i) => `${E + i * larg + larg / 2},${y(Math.max(0, d.lucro))}`).join(' ');
  const passo = Math.max(1, Math.ceil(lista.length / 10));
  const rotulos = lista.map((d, i) => (i % passo === 0 ? `<text x="${E + i * larg + larg / 2}" y="${H - 12}" text-anchor="middle" font-size="11" fill="#5B5466">${d.dia.slice(8)}/${d.dia.slice(5, 7)}</text>` : '')).join('');
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Faturamento e lucro por dia">${linhas}${barras}
    <polyline points="${pontos}" fill="none" stroke="#9F31D3" stroke-width="2.5" stroke-linejoin="round"/>${rotulos}</svg>
    <div class="muted" style="font-size:.85rem;display:flex;gap:16px"><span><span style="display:inline-block;width:12px;height:12px;background:#E4CCF4;border-radius:3px;vertical-align:-1px"></span> Faturamento</span>
    <span><span style="display:inline-block;width:14px;height:3px;background:#9F31D3;vertical-align:3px"></span> Lucro</span><span>valores em R$</span></div>`;
}
function barrasH(itens, valor, rotulo, cor = '#9F31D3') {
  const max = Math.max(1, ...itens.map(valor));
  return itens.map((it) => `<div style="margin:10px 0">
    <div style="display:flex;justify-content:space-between;gap:10px;font-size:.92rem"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(it.nome || it.produto)}</span><strong>${rotulo(it)}</strong></div>
    <div style="height:8px;background:#F1E9F8;border-radius:999px;margin-top:5px;overflow:hidden"><div style="height:100%;width:${Math.max(2, (valor(it) / max) * 100)}%;background:${cor};border-radius:999px"></div></div></div>`).join('') || '<div class="vazio">Sem dados no período.</div>';
}
export function adminFinanceiro({ ini, fim, totais, recargas, novos, diario, porProduto, topGasto, topComissao, extrato, saldoApiFull, clientesTotal, saldoCarteiras }) {
  const receita = totais.bruto - totais.comissoes;
  const lucro = receita - totais.custo;
  const margem = receita ? Math.round((lucro / receita) * 100) : 0;
  const ticket = totais.n ? Math.round(receita / totais.n) : 0;
  const tipoCor = { Recarga: 'var(--ok)', Consulta: 'var(--roxo)', 'Consulta interna': 'var(--cinza)', 'Comissão': '#B7791F', 'Saque pago': 'var(--erro)' };
  return `<h1 style="font-size:1.7rem">Financeiro</h1>${menu('/admin/financeiro')}
<form method="get" class="cartao" style="padding:16px;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;margin-bottom:18px">
  <div class="campo" style="margin:0"><label for="inicio">Data inicial</label><input id="inicio" name="inicio" type="date" value="${ini}" style="font:inherit;padding:11px 13px;border:1.5px solid #D6CCE0;border-radius:12px"></div>
  <div class="campo" style="margin:0"><label for="fim">Data final</label><input id="fim" name="fim" type="date" value="${fim}" style="font:inherit;padding:11px 13px;border:1.5px solid #D6CCE0;border-radius:12px"></div>
  <button class="btn">Aplicar</button>
  <span class="muted" style="font-size:.85rem">Atalhos: <a href="?inicio=${fim}&fim=${fim}">hoje</a> · <a href="/admin/financeiro">30 dias</a></span>
</form>
<div class="grade" style="margin-bottom:18px">
  ${num('Recargas pagas', reais(recargas.total), `${recargas.n} recarga(s) · ${reais(recargas.bonus)} em bônus`)}
  ${num('Faturamento com consultas', reais(receita), `${totais.n} consultas · ticket médio ${reais(ticket)}`)}
  ${num('Custo APIFull', reais(totais.custo), saldoApiFull === null ? 'saldo APIFull indisponível' : `saldo atual na APIFull: ${reais(saldoApiFull)}`)}
  <div class="cartao"><div class="muted">Lucro no período</div><div style="font-family:Montserrat,sans-serif;font-size:1.8rem;font-weight:800;color:var(--ok)">${reais(lucro)}</div><div class="muted" style="font-size:.85rem">margem de ${margem}% sobre o faturamento</div></div>
</div>
<div class="grade" style="margin-bottom:18px">
  ${num('Clientes', clientesTotal, `${novos} novo(s) no período · ${totais.clientes} consultaram`)}
  ${num('Comissões de indicação', reais(totais.comissoes), 'pagas pelos indicados, acima do seu preço')}
  ${num('Saldo nas carteiras', reais(saldoCarteiras), 'créditos dos clientes ainda não usados')}
</div>
<div class="cartao" style="margin-bottom:18px"><h3>Evolução diária</h3>${graficoDiario(diario, ini, fim)}</div>
<div class="grade" style="margin-bottom:18px;grid-template-columns:repeat(auto-fit,minmax(320px,1fr))">
  <div class="cartao"><h3>Quem mais gasta</h3>${barrasH(topGasto, (x) => x.gasto, (x) => `${reais(x.gasto)} · ${x.n} consultas`)}</div>
  <div class="cartao"><h3>Quem mais ganha comissão</h3>${barrasH(topComissao, (x) => x.ganho, (x) => `${reais(x.ganho)} · ${x.n} consultas`, '#B7791F')}</div>
</div>
<div class="cartao" style="margin-bottom:18px"><h3>Lucro por consulta</h3><div class="rolar"><table class="tabela">
  <tr><th>Consulta</th><th>Qtde</th><th>Faturamento</th><th>Custo APIFull</th><th>Lucro</th><th>Lucro médio</th><th>Margem</th></tr>
  ${porProduto.map((p) => { const l = p.receita - p.custo; return `<tr><td><strong>${esc(p.produto)}</strong></td><td>${p.n}</td><td>${reais(p.receita)}</td><td>${reais(p.custo)}</td>
    <td><strong style="color:var(--ok)">${reais(l)}</strong></td><td>${reais(Math.round(l / p.n))}</td><td>${p.receita ? Math.round((l / p.receita) * 100) : 0}%</td></tr>`; }).join('') || '<tr><td colspan="7" class="vazio">Sem consultas no período.</td></tr>'}
</table></div></div>
<div class="cartao"><h3>Extrato detalhado</h3><p class="muted" style="margin-top:-6px">Até 300 movimentações mais recentes do período.</p><div class="rolar"><table class="tabela">
  <tr><th>Data</th><th>Tipo</th><th>Cliente</th><th>Detalhe</th><th style="text-align:right">Valor</th><th style="text-align:right">Seu lucro</th></tr>
  ${extrato.map((e) => `<tr><td>${dt(e.quando)}</td><td><span style="color:${tipoCor[e.tipo] || 'inherit'};font-weight:700">${esc(e.tipo)}</span></td><td>${esc(e.cliente)}</td><td>${esc(e.item)}</td>
    <td style="text-align:right">${e.valor < 0 ? '-' : ''}${reais(Math.abs(e.valor))}</td><td style="text-align:right">${e.lucro === null ? '—' : `<strong style="color:var(--ok)">${reais(e.lucro)}</strong>`}</td></tr>`).join('') || '<tr><td colspan="6" class="vazio">Sem movimentações no período.</td></tr>'}
</table></div></div>`;
}

// ---------- Anúncios ----------
// ---------- Página pública para anunciantes ----------
export function paginaAnuncie({ planos, arte, vagas, max, mostrarNumeros, clientes, exib, whats }) {
  const fmt = (n) => Number(n).toLocaleString('pt-BR');
  const msg = (pl) => `${whats}${whats.includes('?') ? '%20' : '?text='}${encodeURIComponent(`- plano ${pl}`)}`;
  return `<div style="max-width:980px;margin:0 auto">
<span class="tag">Para empresas</span>
<h1 style="font-size:2rem;margin:10px 0 6px">Anuncie para quem está cuidando do crédito</h1>
<p class="muted" style="max-width:720px;margin:0 0 20px">Todo dia, pessoas e empresas entram na Soft Consultas para consultar CPF, CNPJ, veículos e limpar o nome. Seu banner aparece para esse público no momento em que ele está tomando decisões financeiras.</p>
${mostrarNumeros ? `<div class="grade" style="margin-bottom:18px">
  <div class="cartao"><div class="muted">Clientes cadastrados</div><div style="font-family:Montserrat,sans-serif;font-size:1.8rem;font-weight:800">${fmt(clientes)}</div></div>
  <div class="cartao"><div class="muted">Exibições de banners até hoje</div><div style="font-family:Montserrat,sans-serif;font-size:1.8rem;font-weight:800">${fmt(exib)}</div></div>
</div>` : ''}
<div class="cartao" style="margin-bottom:18px">
  <h2 style="font-size:1.3rem;margin-top:0">Onde o seu banner aparece</h2>
  <p style="margin:6px 0">✓ Na <strong>página inicial</strong> do site &nbsp; ✓ No <strong>painel</strong> de cada cliente logado &nbsp; ✓ No <strong>histórico de consultas</strong></p>
  <p class="muted" style="margin:6px 0 0">Rodízio com no máximo <strong>${max} anunciantes</strong> ao mesmo tempo, trocando a cada 6 segundos. Cada clique leva direto ao seu site, WhatsApp ou Instagram. Você recebe o relatório de exibições e cliques.</p>
  <p style="margin:12px 0 0"><strong>${vagas ? `${vagas} ${vagas === 1 ? 'vaga disponível' : 'vagas disponíveis'} agora.` : 'Espaços ocupados no momento: fale com a gente para entrar na fila.'}</strong></p>
</div>
<h2 style="font-size:1.3rem">Planos</h2>
<div class="grade" style="margin-bottom:18px">
  ${planos.map((p) => `<div class="cartao" style="${p.k === 'mensal' ? 'border:2px solid var(--roxo)' : ''}">
    ${p.k === 'mensal' ? '<span class="tag">Mais escolhido</span>' : ''}
    <h3 style="margin:8px 0 4px">${esc(p.n)}</h3>
    <div style="font-family:Montserrat,sans-serif;font-size:1.7rem;font-weight:800">${reais(p.v)}</div>
    <p class="muted" style="margin:4px 0 12px">${p.dias} dias no ar${p.exclusivo ? ' · <strong>só o seu banner</strong>, sem dividir espaço' : ` · ${reais(Math.round(p.v / p.dias))} por dia`}</p>
    <a class="btn ${p.k === 'mensal' ? '' : 'sec'}" href="${esc(msg(p.n))}" target="_blank" rel="noopener">Quero este plano</a></div>`).join('')}
</div>
<div class="cartao" style="margin-bottom:18px">
  <h2 style="font-size:1.3rem;margin-top:0">Formatos e tamanhos</h2>
  <div class="rolar"><table class="tabela">
    <tr><th>Peça</th><th>Tamanho</th><th>Formato</th></tr>
    <tr><td><strong>Banner computador</strong> (obrigatório)</td><td>1600 × 400 px (4:1)</td><td>PNG, JPG ou WEBP · até 3 MB</td></tr>
    <tr><td><strong>Banner celular</strong> (recomendado)</td><td>1200 × 600 px (2:1)</td><td>PNG, JPG ou WEBP · até 3 MB</td></tr>
  </table></div>
  <p class="muted" style="margin:10px 0 0">Sem a versão para celular, o banner de computador é cortado nas laterais no celular: mantenha logo e texto dentro da <strong>área central de 1000 × 400 px</strong>. Evite letras pequenas (mínimo de 40 px de altura no arquivo). O selo "Anúncio" fica no canto superior esquerdo: deixe esse canto livre.</p>
  ${arte ? `<p style="margin:12px 0 0"><strong>Não tem o banner?</strong> Criamos para você por ${reais(arte)}: basta enviar o logo (PNG, mínimo 500 px, de preferência com fundo transparente), as cores da marca, a frase principal e o link.</p>` : ''}
</div>
<div class="cartao" style="margin-bottom:18px">
  <h2 style="font-size:1.3rem;margin-top:0">O que precisamos de você</h2>
  <p style="margin:4px 0">1. Nome da empresa, CNPJ (ou CPF) e um responsável com WhatsApp</p>
  <p style="margin:4px 0">2. Banner nos tamanhos acima (ou logo e textos, se quiser que a gente crie)</p>
  <p style="margin:4px 0">3. Link de destino: site, WhatsApp (wa.me) ou Instagram</p>
  <p style="margin:4px 0">4. Plano e data de início</p>
  <p style="margin:4px 0">5. Pagamento antecipado via Pix. O banner entra no ar em até 1 dia útil depois da aprovação.</p>
</div>
<div class="cartao" style="margin-bottom:18px">
  <h2 style="font-size:1.3rem;margin-top:0">Regras de publicação</h2>
  <p class="muted" style="margin:4px 0">Todos os banners passam por aprovação. Não publicamos: promessa de crédito garantido ou "sem consulta", cobrança antecipada para liberar empréstimo, apostas, conteúdo adulto, pirâmides, produtos ilegais, uso de marcas de terceiros sem autorização ou qualquer conteúdo enganoso. O anunciante é responsável pelo conteúdo e pela oferta anunciada, conforme o Código de Defesa do Consumidor e a LGPD.</p>
</div>
<p style="text-align:center"><a class="btn" href="${esc(whats)}" target="_blank" rel="noopener">Falar com a gente no WhatsApp</a></p>
</div>`;
}

export function adminAnuncios({ anuncios, planos = [], arte = 0, max = 4, noAr = 0, exclusivoNoAr = false, mostrarNumeros = false, ok, erro }) {
  const hoje = new Date(Date.now() - 3 * 3600000).toISOString().slice(0, 10);
  const status = (a) => (!a.ativo ? '<span class="muted">Pausado</span>' : a.fim && a.fim < hoje ? '<span style="color:var(--erro)">Encerrado</span>'
    : a.inicio && a.inicio > hoje ? 'Agendado' : '<span style="color:var(--ok);font-weight:700">No ar</span>');
  return `<h1 style="font-size:1.7rem">Anúncios</h1>${menu('/admin/anuncios')}${aviso(ok, erro)}
<div class="cartao" style="margin-bottom:18px">
  <h3>Novo anúncio</h3>
  <p class="muted">Aparece na página inicial, no painel e no histórico, em rodízio de 6 s. <strong>No ar agora: ${noAr} de ${max} espaços</strong>${exclusivoNoAr ? ' · <strong>há um destaque exclusivo no ar</strong> (só ele aparece até acabar)' : ''}. Banner de computador: <strong>1600 × 400 px</strong> (4:1). Celular (opcional): <strong>1200 × 600 px</strong> (2:1). PNG, JPG ou WEBP, até 3 MB cada. Página para mandar ao anunciante: <a href="/anuncie" target="_blank" rel="noopener">/anuncie</a>.</p>
  <form method="post" action="/admin/anuncios/criar" enctype="multipart/form-data" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px 16px;align-items:end">
    <div class="campo" style="margin:0"><label for="anunciante">Anunciante</label><input id="anunciante" name="anunciante" type="text" required></div>
    <div class="campo" style="margin:0"><label for="titulo">Texto alternativo (descrição do banner)</label><input id="titulo" name="titulo" type="text"></div>
    <div class="campo" style="margin:0"><label for="link">Link de destino</label><input id="link" name="link" type="text" placeholder="https://"></div>
    <div class="campo" style="margin:0"><label for="plano">Plano</label><select id="plano" name="plano" style="min-height:46px"><option value="">Sem plano (valor e datas manuais)</option>${planos.map((p) => `<option value="${esc(p.k)}">${esc(p.n)} · ${p.dias} dias · ${reais(p.v)}</option>`).join('')}</select></div>
    <label style="display:flex;gap:8px;align-items:center;margin:0 0 12px"><input type="checkbox" name="arte" value="1" style="width:20px;height:20px"> Arte feita por nós (+${reais(arte)})</label>
    <div class="campo" style="margin:0"><label for="valor">Valor cobrado (R$) · vazio = preço do plano</label><input id="valor" name="valor" type="text" inputmode="decimal"></div>
    <div class="campo" style="margin:0"><label for="contato">Contato do anunciante (CNPJ / WhatsApp)</label><input id="contato" name="contato" type="text"></div>
    <div class="campo" style="margin:0"><label for="inicio">Início</label><input id="inicio" name="inicio" type="date" style="font:inherit;padding:11px 13px;border:1.5px solid #D6CCE0;border-radius:12px"></div>
    <div class="campo" style="margin:0"><label for="fim">Fim · vazio = calculado pelo plano</label><input id="fim" name="fim" type="date" style="font:inherit;padding:11px 13px;border:1.5px solid #D6CCE0;border-radius:12px"></div>
    <div class="campo" style="margin:0"><label for="imagem">Banner computador (1600 × 400)</label><input id="imagem" name="imagem" type="file" accept="image/png,image/jpeg,image/webp" required></div>
    <div class="campo" style="margin:0"><label for="imagem_mobile">Banner celular (1200 × 600, opcional)</label><input id="imagem_mobile" name="imagem_mobile" type="file" accept="image/png,image/jpeg,image/webp"></div>
    <button class="btn" type="submit">Publicar anúncio</button>
  </form>
</div>
<form class="cartao" method="post" action="/admin/anuncios/planos" style="margin-bottom:18px">
  <h3 style="margin-top:0">Tabela de preços</h3>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px 16px">
    ${planos.map((p) => `<div class="campo" style="margin:0"><label for="v_${esc(p.k)}">${esc(p.n)} (${p.dias} dias)</label><input id="v_${esc(p.k)}" name="v_${esc(p.k)}" type="text" inputmode="decimal" value="${(p.v / 100).toFixed(2).replace('.', ',')}"></div>`).join('')}
    <div class="campo" style="margin:0"><label for="arte">Criação da arte</label><input id="arte" name="arte" type="text" inputmode="decimal" value="${(arte / 100).toFixed(2).replace('.', ',')}"></div>
    <div class="campo" style="margin:0"><label for="max">Máx. anunciantes ao mesmo tempo</label><input id="max" name="max" type="text" inputmode="numeric" value="${max}"></div>
  </div>
  <label style="display:flex;gap:8px;align-items:center;margin:12px 0"><input type="checkbox" name="numeros" value="1" ${mostrarNumeros ? 'checked' : ''} style="width:20px;height:20px"> Mostrar nº de clientes e exibições na página /anuncie</label>
  <button class="btn sec">Salvar preços</button>
</form>
<div class="cartao"><div class="rolar"><table class="tabela">
  <tr><th>Banner</th><th>Anunciante</th><th>Período</th><th>Exibições</th><th>Cliques</th><th>CTR</th><th>Valor</th><th>Status</th><th></th></tr>
  ${anuncios.map((a) => `<tr><td><img src="/anuncio-img/${a.id}" alt="" style="width:160px;aspect-ratio:4/1;object-fit:cover;border-radius:8px"></td>
    <td><strong>${esc(a.anunciante)}</strong>${a.exclusivo ? ' <span class="tag">exclusivo</span>' : ''}<br><small class="muted">${esc(a.link || 'sem link')}</small>${a.contato ? `<br><small class="muted">${esc(a.contato)}</small>` : ''}${a.imagem_mobile ? '<br><small class="muted">com versão celular</small>' : ''}</td>
    <td>${a.inicio ? a.inicio.split('-').reverse().join('/') : 'já'} → ${a.fim ? a.fim.split('-').reverse().join('/') : 'sem fim'}</td>
    <td>${a.impressoes}</td><td>${a.cliques}</td><td>${a.impressoes ? ((a.cliques / a.impressoes) * 100).toFixed(1) : '0.0'}%</td><td>${a.valor_centavos ? reais(a.valor_centavos) : '—'}</td><td>${status(a)}</td>
    <td><form method="post" action="/admin/anuncios/acao" style="display:flex;gap:6px;margin:0"><input type="hidden" name="id" value="${a.id}">
      <button class="btn sec" name="acao" value="alternar" style="min-height:36px;padding:6px 12px">${a.ativo ? 'Pausar' : 'Ativar'}</button>
      <button class="btn sec" name="acao" value="excluir" style="min-height:36px;padding:6px 12px" data-confirmar="Excluir o anúncio de ${esc(a.anunciante)}?">Excluir</button></form></td></tr>`).join('') || '<tr><td colspan="9" class="vazio">Nenhum anúncio cadastrado. Enquanto não houver, aparece o espaço "Anuncie aqui".</td></tr>'}
</table></div></div>`;
}

// ---------- Campanhas de tráfego pago ----------
export function adminCampanhas({ ini, fim, linhas, rastreio, base }) {
  const site = base || 'https://softconsultas.com';
  const paginas = [['limpa-nome', 'Profissionais de limpa nome'], ['veiculos', 'Veículos (lojas, revendas e compradores)'], ['advogados', 'Advogados'], ['empresas', 'Empresas']];
  const exemplo = (pub, fonte, meio) => `${site}/para/${pub}?utm_source=${fonte}&utm_medium=${meio}&utm_campaign=${pub}`;
  const tot = linhas.reduce((t, l) => ({ c: t.c + l.cadastros, p: t.p + l.pagantes, r: t.r + l.recarregado, l: t.l + l.lucro }), { c: 0, p: 0, r: 0, l: 0 });
  return `<h1 style="font-size:1.7rem">Campanhas</h1>${menu('/admin/campanhas')}
<form method="get" class="cartao" style="padding:16px;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;margin-bottom:18px">
  <div class="campo" style="margin:0"><label for="inicio">Cadastros de</label><input id="inicio" name="inicio" type="date" value="${ini}" style="font:inherit;padding:11px 13px;border:1.5px solid #D6CCE0;border-radius:12px"></div>
  <div class="campo" style="margin:0"><label for="fim">até</label><input id="fim" name="fim" type="date" value="${fim}" style="font:inherit;padding:11px 13px;border:1.5px solid #D6CCE0;border-radius:12px"></div>
  <button class="btn">Aplicar</button></form>
<div class="grade" style="margin-bottom:18px">
  ${num('Cadastros', tot.c)}${num('Viraram pagantes', tot.p, `${tot.c ? Math.round((tot.p / tot.c) * 100) : 0}% dos cadastros`)}
  ${num('Recarregado por eles', reais(tot.r))}${num('Seu lucro com eles', reais(tot.l))}
</div>
<div class="cartao" style="margin-bottom:18px"><h3>Resultado por campanha</h3>
  <p class="muted" style="margin-top:-6px">Clientes cadastrados no período, agrupados pela campanha de onde vieram. Compare o lucro de cada uma com o que você gastou em anúncios.</p>
  <div class="rolar"><table class="tabela"><tr><th>Campanha</th><th>Fonte</th><th>Cadastros</th><th>Pagantes</th><th>Conversão</th><th>Recarregado</th><th>Consultas</th><th>Seu lucro</th></tr>
  ${linhas.map((l) => `<tr><td><strong>${esc(l.campanha)}</strong></td><td>${esc(l.fonte)}</td><td>${l.cadastros}</td><td>${l.pagantes}</td><td>${l.cadastros ? Math.round((l.pagantes / l.cadastros) * 100) : 0}%</td>
    <td>${reais(l.recarregado)}</td><td>${l.consultas}</td><td><strong style="color:var(--ok)">${reais(l.lucro)}</strong></td></tr>`).join('') || '<tr><td colspan="8" class="vazio">Nenhum cadastro no período.</td></tr>'}
  </table></div></div>
<div class="cartao" style="margin-bottom:18px"><h3>Páginas de campanha e links prontos</h3>
  <p class="muted" style="margin-top:-6px">Use estes links nos anúncios. O sistema registra de onde cada cliente veio. Troque <code>utm_campaign</code> para separar anúncios diferentes (ex.: limpa-nome-video1).</p>
  ${paginas.map(([pub, nome]) => `<div style="border-top:1px solid var(--borda);padding:12px 0">
    <strong>${nome}</strong> · <a href="/para/${pub}" target="_blank" rel="noopener">ver página</a>
    <div class="muted" style="font-size:.85rem;margin-top:6px">Meta (Instagram/Facebook):</div><code style="word-break:break-all;font-size:.82rem">${esc(exemplo(pub, 'meta', 'pago'))}</code>
    <div class="muted" style="font-size:.85rem;margin-top:6px">Google Ads:</div><code style="word-break:break-all;font-size:.82rem">${esc(exemplo(pub, 'google', 'cpc'))}</code></div>`).join('')}
</div>
<div class="cartao"><h3>Pixel e tags</h3>
  <table class="tabela">
    <tr><td>Pixel da Meta (<code>META_PIXEL_ID</code>)</td><td>${rastreio.meta ? '<strong style="color:var(--ok)">ativo</strong>' : '<span class="muted">não configurado</span>'}</td></tr>
    <tr><td>Google Analytics / Ads (<code>GOOGLE_TAG_ID</code>)</td><td>${rastreio.google ? '<strong style="color:var(--ok)">ativo</strong>' : '<span class="muted">não configurado</span>'}</td></tr>
    <tr><td>Conversão Google Ads: cadastro (<code>GOOGLE_ADS_CONV_CADASTRO</code>)</td><td>${rastreio.convCadastro ? '<strong style="color:var(--ok)">ativo</strong>' : '<span class="muted">opcional</span>'}</td></tr>
    <tr><td>Conversão Google Ads: recarga (<code>GOOGLE_ADS_CONV_RECARGA</code>)</td><td>${rastreio.convRecarga ? '<strong style="color:var(--ok)">ativo</strong>' : '<span class="muted">opcional</span>'}</td></tr>
  </table>
  <p class="muted" style="font-size:.88rem;margin-bottom:0">Eventos enviados: visita de página, clique em "Criar conta" (Lead), cadastro concluído (CompleteRegistration / sign_up) e recarga paga com o valor (Purchase).</p>
</div>`;
}

export function adminOperacao({ aviso: texto, pausadas, repasse, acumulado, repasses, saldoApiFull, saldoAsaas, emails, ok, erro }) {
  const st = { pago: '<span style="color:var(--ok);font-weight:700">Pago</span>', erro: '<span style="color:var(--erro);font-weight:700">Falhou</span>', processando: 'Processando', enviado: '<span style="color:#9A6B00;font-weight:700">Enviado ao Asaas</span>', cancelado: '<span class="muted">Cancelado</span>' };
  return `<h1 style="font-size:1.7rem">Operação</h1>${menu('/admin/operacao')}${aviso(ok, erro)}
<div class="grade" style="margin-bottom:18px">
  ${num('Saldo na APIFull', saldoApiFull === null ? '—' : reais(saldoApiFull), 'paga as consultas dos clientes')}
  ${num('Saldo na conta Asaas', saldoAsaas === null ? '—' : reais(saldoAsaas), 'de onde sai o repasse (conta compartilhada com a Soft Crédito)')}
  ${num('Acumulado para repassar', reais(acumulado.valor), `${acumulado.ids.length} recarga(s) paga(s) desde que o repasse foi ligado`)}
</div>

<form class="cartao" method="post" action="/admin/operacao/repasse" style="max-width:720px;margin-bottom:18px">
  <h2 style="font-size:1.2rem;margin-top:0">Repasse automático para a APIFull</h2>
  <p class="muted" style="margin-top:0">Quando ligado, uma parte de cada recarga paga pelos clientes vira saldo na APIFull: o sistema gera um Pix de recarga na APIFull e paga com o saldo do Asaas, sozinho. Valores pequenos são somados até o lote mínimo. Só entram recargas pagas <strong>depois</strong> de ligar.</p>
  <label style="display:flex;gap:10px;align-items:center;margin-bottom:14px;font-weight:700"><input type="checkbox" name="ativo" value="1" ${repasse.ativo ? 'checked' : ''} style="width:22px;height:22px"> Repasse automático ligado</label>
  <div style="display:flex;gap:12px;flex-wrap:wrap">
    <div class="campo" style="flex:1 1 160px"><label for="pct">Percentual de cada recarga (%)</label><input id="pct" name="pct" type="text" inputmode="decimal" value="${repasse.pct}"></div>
    <div class="campo" style="flex:1 1 180px"><label for="minimo">Repassar quando juntar (R$)</label><input id="minimo" name="minimo" type="text" inputmode="decimal" value="${(repasse.minimo / 100).toFixed(2).replace('.', ',')}"><small class="muted">Mínimo R$ 10,00 (regra da APIFull).</small></div>
  </div>
  <button class="btn" type="submit">Salvar repasse</button>
</form>
<form method="post" action="/admin/operacao/repassar-agora" style="margin:-6px 0 18px"><button class="btn sec" data-confirmar="Repassar agora ${reais(acumulado.valor)} para a APIFull?" ${acumulado.valor < 1000 ? 'disabled' : ''}>Repassar agora o acumulado (${reais(acumulado.valor)})</button></form>

<div class="cartao" style="margin-bottom:18px"><h2 style="font-size:1.2rem;margin-top:0">Histórico de repasses</h2>
${repasses.length ? `<div class="rolar"><table class="tabela"><tr><th>#</th><th>Data</th><th>Valor</th><th>Origem</th><th>Status</th><th></th></tr>
${repasses.map((r) => `<tr><td>${r.id}</td><td>${dt(r.criado_em)}</td><td><strong>${reais(r.valor_centavos)}</strong></td><td>${esc(r.origem)}</td>
  <td>${st[r.status] || esc(r.status)}${r.erro ? `<br><small class="muted">${esc(r.erro)}</small>` : ''}</td>
  <td>${r.status === 'erro' ? `<form method="post" action="/admin/operacao/repasse-tentar" style="display:flex;gap:6px;margin:0"><input type="hidden" name="id" value="${r.id}"><button class="btn sec" name="acao" value="tentar" style="min-height:32px;padding:4px 10px;font-size:.8rem">Tentar de novo</button><button class="btn sec" name="acao" value="cancelar" style="min-height:32px;padding:4px 10px;font-size:.8rem">Cancelar</button></form>` : ''}</td></tr>`).join('')}</table></div>` : '<p class="muted">Nenhum repasse ainda.</p>'}
</div>


<form class="cartao" method="post" action="/admin/operacao/emails" style="max-width:720px;margin-bottom:18px">
  <h2 style="font-size:1.2rem;margin-top:0">E-mails automáticos</h2>
  <p class="muted" style="margin-top:0">Para quem se cadastrou e <strong>ainda não fez a primeira recarga</strong>. O texto se adapta ao perfil (limpa nome, veículos, empresas, advogados) e cita o bônus de primeira recarga quando ele está ativo. Quem recarrega para de receber na hora. Todo e-mail tem link para descadastrar.</p>
  ${emails.temChave ? '' : '<div class="aviso erro">Falta a <code>RESEND_API_KEY</code> no Render: sem ela nenhum e-mail sai.</div>'}
  <label style="display:flex;gap:10px;align-items:center;margin-bottom:12px;font-weight:700"><input type="checkbox" name="ativo" value="1" ${emails.ativo ? 'checked' : ''} style="width:22px;height:22px"> E-mails automáticos ligados</label>
  ${emails.ativo ? `<p class="muted" style="margin-top:-4px">Ligado desde ${dt(emails.desde)} (só cadastros a partir dessa data).</p>` : `<label style="display:flex;gap:10px;align-items:center;margin-bottom:12px"><input type="checkbox" name="incluir_recentes" value="1" style="width:20px;height:20px"> Ao ligar, incluir quem se cadastrou nos últimos 7 dias</label>`}
  <div style="display:flex;gap:18px;flex-wrap:wrap;margin-bottom:14px">${emails.etapasLista.map((e) => {
    const env = emails.enviados.filter((x) => x.etapa === e.chave);
    const n = (st) => env.find((x) => x.status === st)?.n || 0;
    return `<label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="etapa_${e.chave}" value="1" ${emails.etapas.includes(e.chave) ? 'checked' : ''} style="width:20px;height:20px"> ${e.nome} <span class="muted" style="font-size:.85rem">(${n('enviado')} enviados${n('erro') ? `, ${n('erro')} com erro` : ''})</span></label>`;
  }).join('')}</div>
  <p class="muted">Recarregaram depois de receber um e-mail: <strong>${emails.recargasDepois}</strong> · Descadastrados: ${emails.descadastrados}</p>
  <div style="background:#F6ECFC;border-radius:12px;padding:12px 14px;margin:0 0 14px">
    <strong>Limite diário de marketing:</strong> ${emails.hoje} de ${emails.limite} usados hoje (automáticos + campanhas).
    ${emails.pausaAte ? `<br><strong style="color:var(--erro)">Pausado pelo provedor (cota diária atingida) até ${dt(emails.pausaAte)}.</strong>` : ''}
    ${emails.fila.length ? `<br>Campanhas na fila: ${emails.fila.map((x) => `${esc(x.nome)} (faltam ${x.faltam})`).join(' · ')}` : ''}
    <div class="campo" style="margin:10px 0 0"><label for="limite">E-mails de marketing por dia</label><input id="limite" name="limite" type="text" inputmode="numeric" value="${emails.limite}" style="max-width:140px">
      <small class="muted">No plano grátis do Resend o total é 100/dia (contando senha, boas-vindas e avisos). Deixe 80. No plano pago, pode subir para 1.500 ou mais.</small></div>
    ${emails.pausaAte ? '<label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" name="despausar" value="1" style="width:20px;height:20px"> Já aumentei o plano: retomar agora</label>' : ''}
  </div>
  <button class="btn" type="submit">Salvar e-mails automáticos</button>
</form>
<div class="cartao" style="max-width:720px;margin-bottom:18px">
  <h2 style="font-size:1.1rem;margin-top:0">Ver e testar os e-mails</h2>
  <p class="muted" style="margin-top:0">O e-mail de <strong>boas-vindas</strong> é enviado sempre, logo após o cadastro (não depende do botão acima).</p>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">${emails.perfis.map((pf) => `<a class="btn sec" style="min-height:32px;padding:4px 10px;font-size:.78rem" target="_blank" rel="noopener" href="/admin/emails/previa?etapa=boasvindas&perfil=${pf}">BOAS-VINDAS · ${pf}</a>`).join('')}${emails.etapasLista.map((e) => emails.perfis.map((pf) => `<a class="btn sec" style="min-height:32px;padding:4px 10px;font-size:.78rem" target="_blank" rel="noopener" href="/admin/emails/previa?etapa=${e.chave}&perfil=${pf}">${e.chave.toUpperCase()} · ${pf}</a>`).join('')).join('')}</div>
  <form method="post" action="/admin/emails/teste" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0">
    <select name="etapa" aria-label="Etapa" style="min-height:40px"><option value="boasvindas">Boas-vindas</option>${emails.etapasLista.map((e) => `<option value="${e.chave}">${e.nome}</option>`).join('')}</select>
    <select name="perfil" aria-label="Perfil" style="min-height:40px">${emails.perfis.map((pf) => `<option value="${pf}">${pf}</option>`).join('')}</select>
    <button class="btn sec">Enviar teste para o meu e-mail</button>
  </form>
</div>

${(emails.campanhas || []).map((c) => `<form class="cartao" method="post" action="/admin/emails/campanha" style="max-width:720px;margin-bottom:18px">
  <h2 style="font-size:1.2rem;margin-top:0">Campanha de e-mail: ${esc(c.nome)}</h2>
  <p class="muted" style="margin-top:0">${c.semanal ? `Campanha semanal: pode ser disparada uma vez por lote (próximo: <strong>${c.lote.split('-').reverse().join('/')}</strong>, já enviados para este lote: <strong>${c.enviadosSemana}</strong>). Quem já tem pedido pago não recebe.` : 'Disparo único: cada cliente recebe esta campanha uma vez só.'} Respeita quem se descadastrou. Enviados no total: <strong>${c.enviados}</strong>${c.erros ? ` · com erro: ${c.erros}` : ''} · ${c.semanal ? 'pagaram o serviço depois do e-mail' : 'fizeram a consulta depois do e-mail'}: <strong>${c.consultaram}</strong>${c.rodando ? ' · <strong style="color:var(--ok)">enviando agora…</strong>' : ''}</p>
  <input type="hidden" name="c" value="${c.chave}">
  <p style="margin:0 0 12px"><a class="btn sec" style="min-height:34px;padding:6px 14px;font-size:.85rem" target="_blank" rel="noopener" href="/admin/emails/campanha/previa?c=${c.chave}">Ver prévia do e-mail</a>
    <button class="btn sec" name="acao" value="teste" style="min-height:34px;padding:6px 14px;font-size:.85rem">Enviar teste para o meu e-mail</button></p>
  <div class="campo"><label for="publico-${c.chave}">Para quem enviar</label>
    <select id="publico-${c.chave}" name="publico" style="min-height:44px">${Object.entries(emails.publicosCampanha).map(([k, n]) => `<option value="${k}">${esc(n)} (${c.pendentes[k]} a receber)</option>`).join('')}</select></div>
  <div class="campo"><label for="confirmar-${c.chave}">Digite <strong>ENVIAR</strong> para confirmar o disparo</label><input id="confirmar-${c.chave}" name="confirmar" type="text" autocomplete="off" style="max-width:200px"></div>
  <button class="btn" name="acao" value="enviar" ${c.rodando ? 'disabled' : ''}>Disparar campanha</button>
</form>`).join('')}
<form class="cartao" method="post" action="/admin/operacao/aviso" style="max-width:720px">
  <h2 style="font-size:1.2rem;margin-top:0">Aviso geral e manutenção</h2>
  <div class="campo"><label for="aviso">Aviso no topo para todos os clientes logados</label><input id="aviso" name="aviso" type="text" maxlength="300" value="${esc(texto)}" placeholder="Ex.: Instabilidade na base de veículos. Já estamos resolvendo.">
    <small class="muted">Deixe vazio para não mostrar nada.</small></div>
  <label style="display:flex;gap:10px;align-items:center;margin-bottom:14px;font-weight:700;color:${pausadas ? 'var(--erro)' : 'inherit'}"><input type="checkbox" name="pausadas" value="1" ${pausadas ? 'checked' : ''} style="width:22px;height:22px"> Pausar novas consultas (manutenção)</label>
  <p class="muted" style="margin-top:-6px">Use se a APIFull estiver fora do ar ou sem saldo: ninguém é cobrado e o cliente vê uma mensagem de manutenção. Recargas continuam funcionando.</p>
  <button class="btn" type="submit">Salvar</button>
</form>`;
}
